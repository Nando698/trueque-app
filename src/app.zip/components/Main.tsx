'use client'
import React from 'react';

import { useEffect, useState } from 'react'
import { obtenerOfertas } from '../connect/ofertas'
import { renderUtils } from '@/utils/render';
import { validarToken } from '@/connect/auth';


const Main: React.FC = () => {
  const [ofertas, setOfertas] = useState([])

  

  useEffect(() => {
    
     const checkAuth = async () => {
    const valido = await validarToken();
    if (!valido) {
      window.location.href = '/login';
    }
  };

  checkAuth();
    
    
    


    obtenerOfertas()
      .then(setOfertas)
      .catch((error: Error) => {
        console.error('Error al obtener ofertas:', error)
      })
  }, [])

  return (
    <main className="bg-gray-800 min-h-screen grid px-6 pb-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4  gap-6 ">
    
        {renderUtils.renderizarOfertas(ofertas)}
        
    </div>
      
      
      

    </main>
  );
};

export default Main;
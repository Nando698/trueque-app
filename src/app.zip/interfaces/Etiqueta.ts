export interface Etiqueta {
    id: number
    nombre: string
  }
import PublicarOferta from "@/components/Publicar";

export default function Page() {
    return (
      <>
             <div className="bg-white">
< PublicarOferta />
</div>
      </>
  
  
  
    )
  }
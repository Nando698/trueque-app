import FAQContent from "@/components/FAQContent"

export default function Page() {
  return (
    <>
    <div className="bg-gray-800">
      <FAQContent />
      </div>
    </>
  )
}
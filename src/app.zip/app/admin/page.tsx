
export default function Page() {
    return (
      <>
        Admin page
      </>
  
  
  
    )
  }
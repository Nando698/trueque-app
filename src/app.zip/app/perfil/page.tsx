
export default function Page() {
    return (
      <>
perfil page
      </>
  
  
  
    )
  }
import Login from "@/components/Login";

export default function Page() {
  return (
    <>
    <div className="bg-gray-800">
      <Login />
      </div>
    </>
  );
}

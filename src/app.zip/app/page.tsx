
import Main from '../components/Main'

export default function Page() {
  return (
    <>
      <Main />
    </>



  )
}

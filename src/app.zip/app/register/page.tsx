import RegisterPage from "@/components/Register";

export default function Page() {
    return (
      <>
<RegisterPage />
      </>
  
  
  
    )
  }
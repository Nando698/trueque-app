
export default function Page() {
    return (
      <>
Ofertas page
      </>
  
  
  
    )
  }
import BuscarResultados from "@/components/BuscarResultados";

export default function Page() {
  return (
    <div className="bg-gray-800 min-h-screen text-white">
      <BuscarResultados />
    </div>
  );
}
